package com.example.seizuredectection.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.SensorEventListener;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEventListener;
import android.hardware.SensorEvent;
import com.example.seizuredectection.R;

import java.text.DecimalFormat;
import java.util.ArrayList;

//import java.util.*;
//import javax.mail.*;
//import javax.mail.internet.*;
//import javax.activation.*;

public class CallActivity extends AppCompatActivity implements SensorEventListener {

    public static final String TAG = "Debug";

    ArrayList<Float> array1 = new ArrayList<>();
    private static final int MY_PERMISSIONS_REQUEST_CALL_PHONE = 1;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;

    private TextView _prob;
    private Button _call;
    //private Button _sms;
    private TelephonyManager mTelephonyManager;
   // private MyPhoneCallListener mListener;

    private static DecimalFormat df = new DecimalFormat("0.00");


    private static boolean mIsSensorUpdateEnabled = false;

    private SensorManager sensorManager;
    private Sensor sensoracc;

    private LocationManager lm;
    private Location location;
    private double longitude;
    private double latitude;
    private TextView seize2;
    public final static int TAG_PERMISSION_CODE=1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _call = findViewById(R.id.button);
        //_sms = findViewById(R.id.message);
        seize2 = findViewById(R.id.seize1);
        _prob = findViewById(R.id.prob);
        //loc = findViewById(R.id.location);


        mTelephonyManager = (TelephonyManager)
                getSystemService(TELEPHONY_SERVICE);

        //checkForSmsPermission();

//        if(!CheckPermission.checkPermission(this)) {
//            CheckPermission.requestPermission(this,TAG_PERMISSION_CODE);
//
//        }
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
//        }else{
//            // Write you code here if permission already given.
//            try{
//                lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
//                location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//                longitude = location.getLongitude();
//                latitude = location.getLatitude();
//
//                loc.setText("("+latitude+", " + longitude +")");
//
//
//            }
//            catch (SecurityException se){
//                //((TextView)findViewById(R.id.infobox)).setText(se.toString());
//                se.printStackTrace();
//            }
//        }




        if (isTelephonyEnabled()) {
            Log.d(TAG, "Telephony is enabled");
            // ToDo: Check for phone permission.
            checkForPhonePermission();
            sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
            sensoracc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            mIsSensorUpdateEnabled =true;

        } else {
            Toast.makeText(this,
                    "TELEPHONY NOT ENABLED! ",
                    Toast.LENGTH_LONG).show();
            Log.d(TAG, "TELEPHONY NOT ENABLED! ");
            // Disable the call button
            disableCallButton();
        }


        _call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = "tel:2178191291";
//                smsSendMessage();
                Intent dialIntent = new Intent(Intent.ACTION_CALL);
                dialIntent.setData(Uri.parse(phoneNumber));
                if (dialIntent.resolveActivity(getPackageManager()) != null) {
                    checkForPhonePermission();
                    startActivity(dialIntent);
                } else {
                    Log.e(TAG, "Can't resolve app for ACTION_DIAL Intent.");
                }

                finish();

                String phoneNumber1 = "4049604827";

                Intent dialIntent2 = new Intent(Intent.ACTION_CALL);
                dialIntent2.setData(Uri.parse(phoneNumber1));
                if (dialIntent2.resolveActivity(getPackageManager()) != null) {
                    checkForPhonePermission();
                    startActivity(dialIntent2);
                } else {
                    Log.e(TAG, "Can't resolve app for ACTION_DIAL Intent.");
                }

                finish();
            }
        });






    }




    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensoracc, SensorManager.SENSOR_DELAY_UI);
    }

    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void smsSendMessage() {


        String[] arr = new String[3];
        arr[0] = "tel:6785499156";
        arr[1] = "2178191291";



        // Find the sms_message view.

        // Get the text of the SMS message.
        String smsMessage = "HELP, HELP, I am having a seizure. I am at: " + "";
        // Set the service center address if needed, otherwise null.
        String scAddress = null;
        // Set pending intents to broadcast
        // when message sent and when delivered, or set to null.

        PendingIntent sentIntent = null, deliveryIntent = null;
        // Use SmsManager.
        checkForSmsPermission();

        for(int i= 0; i<arr.length; i++) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage
                    (arr[0], scAddress, smsMessage,
                            sentIntent, deliveryIntent);
        }
    }


    private void disableSmsButton() {
        Toast.makeText(this, "SMS usage disabled", Toast.LENGTH_LONG).show();
        Button smsButton = (Button) findViewById(R.id.message);
        smsButton.setVisibility(View.INVISIBLE);
        Button retryButton = (Button) findViewById(R.id.retry);
        retryButton.setVisibility(View.VISIBLE);
    }

    private void enableSmsButton() {
        Button smsButton = (Button) findViewById(R.id.message);
        smsButton.setVisibility(View.VISIBLE);
    }

    private void disableCallButton() {
        Toast.makeText(this,
                "Phone calling disabled", Toast.LENGTH_LONG).show();

        _call.setVisibility(View.INVISIBLE);
        if (isTelephonyEnabled()) {
            Button retryButton = (Button) findViewById(R.id.retry);
            retryButton.setVisibility(View.VISIBLE);
        }
    }


    private void checkForSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "No permission to message!");
            // Permission not yet granted. Use requestPermissions().
            // MY_PERMISSIONS_REQUEST_SEND_SMS is an
            // app-defined int constant. The callback method gets the
            // result of the request.
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            // Permission already granted. Enable the SMS button.
            enableSmsButton();
        }
    }



    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        // Check if permission is granted or not for the request.
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CALL_PHONE: {
                if (permissions[0].equalsIgnoreCase
                        (Manifest.permission.CALL_PHONE)
                        && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted.
                } else {
                    // Permission denied.
                    Log.d(TAG, "Failure to obtain permission!");
                    Toast.makeText(this,
                            "Failure to obtain permission!",
                            Toast.LENGTH_LONG).show();
                    // Disable the call button
                    disableCallButton();
                }
            }
        }
    }

    private void checkForPhonePermission() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "PERMISSION NOT GRANTED!");
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    MY_PERMISSIONS_REQUEST_CALL_PHONE);
        } else {
            // Permission already granted. Enable the call button.

            enableCallButton();
        }
    }

    private boolean isTelephonyEnabled() {
        if (mTelephonyManager != null) {
            if (mTelephonyManager.getSimState() ==
                    TelephonyManager.SIM_STATE_READY) {
                return true;
            }
        }
        return false;
    }


    public void retryApp(View view) {
        enableCallButton();
        Intent intent = getPackageManager()
                .getLaunchIntentForPackage(getPackageName());
        startActivity(intent);
    }

    private void enableCallButton() {

        _call.setVisibility(View.VISIBLE);
    }

    public void call() {

        System.out.println("call");
        String phoneNumber = "2178191291";
        String phoneNumber1 = "4049604827";

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                _call.performClick();
            }
        }, 2000);
        Intent dialIntent = new Intent(Intent.ACTION_DIAL);
        dialIntent.setData(Uri.parse(phoneNumber));
        if (dialIntent.resolveActivity(getPackageManager()) != null) {
            if (dialIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(dialIntent);
            } else {
                Log.e(TAG, "Can't resolve app for ACTION_DIAL Intent.");
            }


        }
        System.out.println("done");
        finish();



    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    int count = 0;

    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];


        if(y < -6.0) {
            count++;
        }

//        array1.add(y);
//
//        if( array1.size() > 100) {
//            array1.clear();
//        }
//
//       count = 10;
//       int datapoint = 20;
//       int size1 = array1.size()-1;
//       while (count > 0) {
//           if (size1 > 0) {
//               if(datapoint > 0) {
//                   if (size1 < array1.size() && size1 > 0) {
//                       array1.get(size1);
//                       if (array1.get(size1) < 3.0) {
//                           count--;
//                       }
//                   }
//                   size1--;
//                   datapoint--;
//               }
//           } else {
//               break;
//           }
//       }



        double probability = ((count / 2) * 9)  %100;
        _prob.setText(probability + "%");
        System.out.println("herehere");
        boolean seizure = false;
        if (probability > 90) {
            seizure = true;
            seize2.setText("Having Seizure");
        }

        float acceleration = (float) Math.sqrt(x*x + y*y + z*z) - SensorManager.GRAVITY_EARTH; //acceleration in the x
        Log.d("Debug", y+"acceleration");
        if (seizure) {

            System.out.println("herehere1234567890");

            stopSensors();
            call();
        }



    }

    private void stopSensors(){
        sensorManager.unregisterListener(this, sensoracc);
        mIsSensorUpdateEnabled =false;
    }





}
