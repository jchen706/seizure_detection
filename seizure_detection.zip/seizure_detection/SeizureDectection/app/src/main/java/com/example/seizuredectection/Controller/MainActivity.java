package com.example.seizuredectection.Controller;

import android.content.Context;

import android.hardware.Sensor;
import android.hardware.SensorManager;

import android.os.Bundle;

import com.example.seizuredectection.R;

import androidx.appcompat.app.AppCompatActivity;

import android.location.Criteria;
import android.location.LocationManager;
import android.widget.Button;
import android.widget.TextView;
import android.telephony.SmsManager;


import android.view.View;
import android.view.Menu;
import android.view.MenuItem;



public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private Sensor sensoracc;
    private LocationManager locationManager;




    private String provider;

    private TextView _prob, _location, _seize;
    private Button call_button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        _prob = findViewById(R.id.prob);
        //_location = findViewById(R.id.location);
        _seize = findViewById(R.id.seize1);

        call_button = findViewById(R.id.button);


        call_button.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                SendMessage();

//                Intent callIntent = new Intent(Intent.ACTION_CALL);
//                callIntent.setData(Uri.parse("tel:678-622-8478,"));
//
//                if (ActivityCompat.checkSelfPermission(MainActivity.this,
//                        Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
//                    return;
//                }
//                startActivity(callIntent);
            }
        });


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Criteria criteria = new Criteria();
        provider = locationManager.getBestProvider(criteria, false);


    }


    public void SendMessage(){
        String messageToSend = "I'm having a seizure. Please help me, this was sent by the app seizure police! Help! Here's a link that could help you help me: https://bit.ly/2sPRubM"; //I am at " + latitude.toString() + " " + longitude.toString();
        String number = "6785499156";

        System.out.println("ABOUT TO SEND ERROR MESSAGE");

        SmsManager.getDefault().sendTextMessage(number, null, messageToSend, null,null);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }






}
