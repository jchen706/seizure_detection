package com.example.seizuredectection.Controller;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;


import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.hardware.SensorEventListener;
import android.hardware.SensorEvent;

import com.example.seizuredectection.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class AccelActivity  extends Activity implements SensorEventListener{

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 1;

    private float prevX, prevY, prevZ;

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private float changeXmax = 0;
    private float changeYmax = 0;
    private float changeZmax = 0;


    private float changeX = 0;
    private float changeY = 0;
    private float changeZ = 0;


    private float thresholdNoise = 0;

    private TextView nowX, nowY, nowZ, maxX, maxY, maxZ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//        _call.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String phoneNumber = "tel:2178191291";
////                smsSendMessage();
//                Intent dialIntent = new Intent(Intent.ACTION_CALL);
//                dialIntent.setData(Uri.parse(phoneNumber));
//                if (dialIntent.resolveActivity(getPackageManager()) != null) {
//                    checkForPhonePermission();
//                    startActivity(dialIntent);
//                } else {
//                    Log.e(TAG, "Can't resolve app for ACTION_DIAL Intent.");
//                }
//
//                finish();
//            }
//        });
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        float acceleration = (float) Math.sqrt(x*x + y*y + z*z) - SensorManager.GRAVITY_EARTH; //acceleration in the x








    }
}
